﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            /*
             Membership sınıfının bir metodu olan Create User metodu   parametre olarak aldığı kullanıcı adı, parola, email (güvenlik sorusu/yanıtı) sahip kullanıcıyı veri tabanına ekler. 
            Membership sınıfı System.Web.Security kütüphanesindedir. 
             
             */

            string kadi = TextBox1.Text;
            string parola=TextBox2.Text;
            string mail=TextBox3.Text;
            string guvenlik_sorusu = DropDownList1.SelectedValue;
            string yanit=TextBox4.Text;

            /*Kullanıcı oluşturan Create User metodu üye kayıt işleminin sonucunu (başarılı/başarısız)tutan MembershipCreateStatus türünde bir değer döndürür. O değişkeni oluşturalım*/
            MembershipCreateStatus uye_oluşturma_sonuc;

            Membership.CreateUser(kadi, parola, mail, guvenlik_sorusu, yanit, true, out uye_oluşturma_sonuc);

            if (uye_oluşturma_sonuc == MembershipCreateStatus.Success)
                Label1.Text = "Kullanıcı kaydı başarılı bir şekilde oluşturuldu";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.DuplicateUserName)
                Label1.Text = "Kullanıcı adı zaten kullanılıyor. Lütfen başka bir kullanıcı ile kayıt olun";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.DuplicateEmail)
                Label1.Text = "e-mail adresi kullanımda. Başka bir e-mail adresi ile kayıt olmayı deneyin";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.InvalidPassword) //parola kriterlerine uyulmadı ise
                Label1.Text = "Lütfen en az 5 karakter uzunluğunda ve en az 1 tane sayı ya da harf olmayan karakter içeren bir parola belirleyin";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.InvalidQuestion)//güvenlik sorusu girilmediğinde oluşan hata
                Label1.Text = "Lütfen bir güvenlik sorusu seçin";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.InvalidAnswer)
                Label1.Text = "Lütfen güvenlik sorusunun yanıtını belirleyin";
            else if (uye_oluşturma_sonuc == MembershipCreateStatus.InvalidUserName) //kullanıcı adı hiç girilmedi ise İnvalidUserName hatası oluşur
                Label1.Text = "Kullanıcı adınızı girin";
            else
                Label1.Text = "Kullanıcı kaydı gerçekleştirilmedi";

        }
    }
}