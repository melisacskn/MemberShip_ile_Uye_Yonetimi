﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class Giris : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //eğer kullanıcı henüz giriş yapmadı ise
            if (Request.Cookies[".ASPXAUTH"] == null)
            {
                Panel1.Visible = true;
                Panel2.Visible = false;
            }
            else
            {
                Panel1.Visible = false;
                Panel2.Visible = true;
                Label2.Text = User.Identity.Name;//oturum açmış kullanıcının kullanıcı adını Label'a aktaralım
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //Giriş Butonu
            if (Membership.ValidateUser(TextBox1.Text, TextBox2.Text) == true)
            {
                if (CheckBox1.Checked == true)//beni hatırla onaylı ise
                {
                    //kimlik doğrulama anahtarının tutulduğu .aspxauth cookiesinin kalıcı olarak istemci tarayıcısında saklanmasını sağlamalıyız
                    FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, true);
                
                }else

                    FormsAuthentication.RedirectFromLoginPage(TextBox1.Text, false);

            }
            else
                Label1.Text = "Kullanıcı adı ya da parola hatalı";


            /*
             Membership sınıfının bir metodu olan ValidateUser metodu parametre olarak aldığı kullanıcı adı ve parolaya sahip kullanıcı kayıtlı ise True değilse False değerini döndürür.
             
             
             RedirectFromLoginPage metodu, giriş sayfasını çağıran bir sayfa var ise giriş işleminin ardından o sayfaya yönlendirir, böyle bir sayfa yok ise web.config dosyasında authendication bildirimleri arasında DefaultUrl özelliği ile tanımlanan sayfaya yönlendirme yapar.

            Bu metot iki parametre alır. Kullanıcı adı ve cookienin kalıcı olarak tutulup tutulmayacağını bildiren boolean değer. True ise kimlik doğrulmayı gerçekleştiren .ASPXAUTH cookie'si istemci tarayıcısında kalıcı olarak saklanır. 
             
             
             */
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //çıkış işlemi 
            FormsAuthentication.SignOut();
            Response.Redirect("Giris.aspx");

            /*signout metodu kimlik doğrulama anahtarının tutulduğu .aspxauth cookiesini tarayıcıdan silerek çıkış işlemini gerçekleştirir */
        }
    }
}