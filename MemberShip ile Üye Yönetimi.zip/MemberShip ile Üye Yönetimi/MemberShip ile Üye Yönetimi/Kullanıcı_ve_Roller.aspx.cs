﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;//membership ve roles sınıflarının kullanılması için ekledik

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class Kullanıcı_ve_Roller : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)//sayfa ilke kez yükleniyor ise
            {
                kullanici_listele();
                rolleri_listele();
            }

        }

        //veri tabanında kayıtlı tüm kullanıcıları okuyan ve dropdownlist1 kontrolüne aktaran metot tanımı yapalım

        void kullanici_listele()
        {
            MembershipUserCollection kullanicilar = Membership.GetAllUsers();//kayıtlı tüm kullanıcıları okuduk
            DropDownList1.DataSource= kullanicilar;
            DropDownList1.DataBind();
        }

        //kayıtlı tüm rolleri okuyan ve Dropdonwlist2'ye aktaran metot tanımı yapalım
        void rolleri_listele()
        {
            string[] roller = Roles.GetAllRoles();
            DropDownList2.DataSource= roller;
            DropDownList2.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "")
            {
                Label1.Text = "Seçilen kullanıcının atanacağı rol belirlenmemiş";
                return;
            }

            //seçilen kullanıcı belirtilen role daha önceden kaydedildi ise 
            //Roles sınıfının bir metodu olan IsUserInRole metodu belirtilen kullanıcıı belirtilen rolde kayıtlı ise True değilse False değerini verir. 
            string secilen_kullanici = DropDownList1.SelectedValue;
            string atanacak_rol = TextBox1.Text;

            if (Roles.IsUserInRole(secilen_kullanici,atanacak_rol) == true)
            {
                Label1.Text = "Seçilen kullanıcı bu role daha önceden atanmış";
                return;
            }

            //seçilen kullanıcıyı belirtilen role atayalım
            Roles.AddUserToRole(secilen_kullanici, atanacak_rol);

           
        }

        //seçili kullanıcının atandığı rolleri listeleyen ve Gridview kontrolünde gösteren metot tanımı yapalım
        void kullanici_rollerini_listele()
        {
            string[] roller = Roles.GetRolesForUser(DropDownList1.SelectedValue);//seçilen kullanıcı rollerini getir
            GridView1.DataSource = roller;
            GridView1.DataBind();

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            kullanici_rollerini_listele();
        }
    }
}