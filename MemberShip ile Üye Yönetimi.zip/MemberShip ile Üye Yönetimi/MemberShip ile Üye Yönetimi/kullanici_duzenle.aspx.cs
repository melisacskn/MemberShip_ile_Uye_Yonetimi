﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class kullanici_duzenle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            string k_adi = TextBox1.Text;
            MembershipUser kullanici=Membership.GetUser(k_adi);
            if (kullanici != null)
            {
                Panel1.Visible = true;
                Label10.Text = " ";
                Label1.Text = kullanici.UserName;//kullanıcı adını göster
                Label2.Text = kullanici.Email;//sistemde kayıtlı e-mail adresini göster

                if (kullanici.IsApproved == true)
                    Label3.Text = "Hesap Onaylanmış";
                else
                    Label3.Text = "Hesap Onaylı Değil";

                if (kullanici.IsLockedOut == true)
                {
                    Label4.Text = "Hesap Kilitli";
                    Button1.Visible = true;
                }
                else
                {
                    Label4.Text = "Hesap Kilitli Değil";
                    Button1.Visible = false;
                }

                if (kullanici.IsOnline == true)
                    Label5.Text = "Çevrimiçi";
                else
                    Label5.Text = "Çevrimiçi değil";
                Label6.Text = kullanici.CreationDate.ToShortDateString();
                Label7.Text=kullanici.LastLoginDate.ToShortDateString();
                Label8.Text = kullanici.LastPasswordChangedDate.ToShortDateString();
                Label9.Text=kullanici.LastActivityDate.ToShortDateString();

            }
            else
                Label10.Text = "Bu kullanıcı sistemde kayıtlı değil";
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            MembershipUser kullanici = Membership.GetUser(TextBox1.Text);
            if (kullanici != null && kullanici.IsLockedOut == true)
            {
                kullanici.UnlockUser();//kullanıcı kilidini açar
                Response.Redirect("kullanici_duzenle.aspx");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Membership.DeleteUser(TextBox1.Text);
            Response.Redirect("kullanici_duzenle.aspx");

            /*DeleteUser metodu parametre olarak adlığı kullanıcı adına sahip kullanıcıyı veri tabanından siler*/
        }
    }
}