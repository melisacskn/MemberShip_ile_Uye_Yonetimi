﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)//Çıkış Butonu
        {
            FormsAuthentication.SignOut();
            Response.Redirect("Login.aspx");
        }

        protected void Login1_LoginError(object sender, EventArgs e)
        {
            //Login kontrolünün bir elemanı olan kullanıcı adını girdiğimiz id'si username olarak tanımlanmış TextBox kontrolüne erişip , girilen kullanıcı adını okuyalım

            System.Web.UI.WebControls.Login login1 = (System.Web.UI.WebControls.Login)LoginView1.FindControl("Login1");
           
            TextBox tb = (TextBox)login1.FindControl("UserName");
            string kadi = tb.Text;

            MembershipUser kullanici = Membership.GetUser(kadi);
            if (kullanici!=null && kullanici.IsLockedOut==true)
            {
                login1.FailureText = "Hesabınız kilitlendi";
            }

        }
    }
}