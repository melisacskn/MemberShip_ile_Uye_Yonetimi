﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;//Roles sınıfı ve metotlarının kullanılması için ekledik

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class Rol_ekle_sil : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            rolleri_listele();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "")
            {
                Label1.Text = "Lütfen eklenecek rol adını girin";
                return;
            }

            //Textbox kontrolüne girilen daha önceden aspnet_Roles tablosuna eklenmiş olabilir. 
            // Roles sınıfının bir metodu olan RoleExists metodu parametre olarak aldığı string ifadeyi aspnet_Roles tablosunda arar, kayıtlı ise True değilse False değerini döndürür. Yani belirtilen rolün daha önceden kayıt edilip edilmediğini kontrol eder

            if (Roles.RoleExists(TextBox1.Text) == true)
            {
                Label1.Text = "Girilen rol kaydı daha önceden yapılmış. Lütfen farklı bir rol adı girin";
                return;
            }

            //TextBox'a girileni aspnet_roles tablosuna kayıt et
            Roles.CreateRole(TextBox1.Text);
            Label1.Text = "Rol kaydı tamamlandı";
            rolleri_listele();
        }

        //Veri Tabanında tanımlı olan tüm rolleri okuyan ve Gridview kontrolüne aktaran metot tanımı yapalım
        void rolleri_listele()
        {
            string[] roller = Roles.GetAllRoles();   /*aspnet_Roles tablosunun içeriğini okumak için Roles sınıfının bir metodu olan GetAllRoles() metodu kullanılır*/
            GridView1.DataSource = roller;
            GridView1.DataBind();
            GridView1.HeaderRow.Cells[1].Text = "Kayıtlı Roller";

        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string secilen_rol = e.Values[0].ToString();
            Roles.DeleteRole(secilen_rol);//belirtilen rolü veri tabanından siler.
            rolleri_listele();
                
        }
    }
}