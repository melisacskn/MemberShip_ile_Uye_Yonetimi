﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MemberShip_ile_Üye_Yönetimi
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //oturum açılmış mı?
            if (Request.Cookies[".ASPXAUTH"] != null)
            {
                MembershipUser kullanici = Membership.GetUser();//oturum açmış kullanıcıyı getirir.
                string kullanici_adi = kullanici.UserName;//oturum açmış kullanıcı adını elde ettil
                if (Roles.IsUserInRole(kullanici_adi, "Admin") == true)
                {
                    LinkButton1.Visible = true;
                }
                else
                    LinkButton1.Visible = false;

            
            }else
                LinkButton1.Visible = false;

        }
    }
}